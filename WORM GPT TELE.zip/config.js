module.exports = {
  BOT_TOKEN: 'YOUR_TELEGRAM_BOT_TOKEN',
  OPENAI_API_KEY: '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',
  OWNER_IDS: ['YOUR_TELEGRAM_USER_ID'], // Array of Telegram user IDs who are owners
  PREMIUM_USERS: [], // Array of Telegram user IDs who are premium users
};

